# Codexium Magnus – Traceability Matrix (v1.0)

| Requirement | Detailed Design Section | Notes |
|-------------|-------------------------|--------|
| FR‑11       | Typography (referenced) | UI Design doc owns visual rules |
| FR‑12       | Bibliography pipeline   | Print Design doc owns print formatting |
