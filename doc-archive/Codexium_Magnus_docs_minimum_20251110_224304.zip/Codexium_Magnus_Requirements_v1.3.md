# Codexium Magnus – Requirements Specification (v1.3)

## New Requirements

### [FR‑11] Typography
The platform shall allow users to configure typography for on‑screen reading.

### [FR‑12] Bibliography
The platform shall generate bibliographies according to APA and CMS formatting and ordering rules.
